
import java.util.ArrayList;

public class Cliente extends Persona{
    
    private String usuario;
    private String password;
    private ArrayList <Reserva> listadoReservas;
    
    public Cliente(String n, String a, int dni, Domicilio d, String usuario, String contrasenia) {
        super(n, a, dni, d);
        
        this.usuario = usuario;
        this.password = contrasenia;
        this.listadoReservas = new ArrayList<>();
    }
    
    
}
