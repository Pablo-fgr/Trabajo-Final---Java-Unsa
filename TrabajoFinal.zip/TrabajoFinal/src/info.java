public class info {

	private String  user="root";
	private String pass="SIUguarani40";
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public info() {
		super();
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
}