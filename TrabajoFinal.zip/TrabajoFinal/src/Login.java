import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {

	private String usuario;
	private String pass;
	private Conexion conn;
	
	public Login() {
	
		
	}
	public Login(String usuario, String pass) {
		
		this.usuario = usuario;
		this.pass = pass;
		this.conn=new Conexion();
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public ResultSet verificarIngreso() throws SQLException {
		//select * from cinemar.usuario where Usuario='PabloFgr'and Password='PabloFgr';
		String sql="select * from cinemar.usuario where Usuario="+"  '"+this.usuario+   "'  "
                                            + " and Password="+"  '"+this.pass+"' "+";"   ;
                                            
		
		ResultSet rs=conn.devolverConsulta(sql);
		
		return rs;
	}
	
	
}