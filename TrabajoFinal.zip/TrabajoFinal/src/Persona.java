public class Persona {

    private String nombre;
    private String apellido;
    private int dni;
    private Domicilio domicilio;
    
    public Persona(String n, String a, int dni, Domicilio d){
        this.nombre = n;
        this.apellido = a;
        this.dni = dni;
        this.domicilio = d;
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni + ", domicilio=" + domicilio + '}';
    }
    
    
}
