public class Domicilio {

}
